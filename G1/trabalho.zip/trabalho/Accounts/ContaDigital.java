public class ContaDigital extends ContaFinanceira{

    public ContaDigital(double SaldoInicial) {
        super(SaldoInicial);
    }

    @Override
    protected void transferencia(double valor) {

        if (Saldo > valor){
        this.Saldo =- valor;
        }else{
        System.out.println("Saldo insuficiente");
        }
    }

    @Override
    protected void credito(double valor) {
        if (Saldo > valor){
        this.Saldo =- valor;
        }else{
        System.out.println("Saldo insuficiente");
        }
    }

    @Override
    protected void debito(double valor) {
        this.Saldo += valor;
    }
}