public abstract class ContaFinanceira {
    protected double Saldo;
    protected abstract void debito(double valor);
    protected abstract void credito(double valor);
    protected abstract void transferencia(double valor);

    public ContaFinanceira (double SaldoInicial){
        this.Saldo=SaldoInicial;
    }
}