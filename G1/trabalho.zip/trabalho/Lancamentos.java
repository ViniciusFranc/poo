public class Lancamentos {
    protected String Tipo;
    protected String Categoria;
    protected String Subcategoria;
    protected String Pagador;
    protected String Beneficiario;
    
}