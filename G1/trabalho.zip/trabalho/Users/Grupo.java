public class Grupo extends Usuario{
    
}