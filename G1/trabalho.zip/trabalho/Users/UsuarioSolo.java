public class UsuarioSolo extends Usuario{
    
}