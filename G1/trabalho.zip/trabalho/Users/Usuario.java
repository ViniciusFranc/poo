public abstract class Usuario{
    
}