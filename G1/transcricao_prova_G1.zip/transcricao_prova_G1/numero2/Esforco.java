public interface Esforco{
    public void medirEsforco();
}